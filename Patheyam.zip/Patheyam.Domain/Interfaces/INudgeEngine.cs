
namespace Patheyam.Domain.Interfaces
{
	public interface INudgeEngine
	{
		bool Nudge(out string message);
	}
}
