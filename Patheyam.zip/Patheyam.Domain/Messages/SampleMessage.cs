
namespace Patheyam.Domain.Messages
{
    public class SampleMessage
    {
        public string Name { get; set; }
    }
}
