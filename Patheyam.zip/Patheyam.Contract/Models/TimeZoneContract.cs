﻿
namespace Patheyam.Contract.Models
{
    public class TimeZoneContract
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public float Hours { get; set; }
        public bool Active { get; set; }
    }
}
