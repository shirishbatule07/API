﻿
namespace Patheyam.Contract.Models
{
    public class StateSearchContract : SearchContract
    {
        public int CountryId { get; set; }
    }
}
