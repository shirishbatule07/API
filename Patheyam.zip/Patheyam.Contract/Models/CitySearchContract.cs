﻿
namespace Patheyam.Contract.Models
{
    public class CitySearchContract : SearchContract
    {
        public int StateId { get; set; }
    }
}
