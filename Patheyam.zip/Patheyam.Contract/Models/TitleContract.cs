﻿
namespace Patheyam.Contract.Models
{
    public class TitleContract
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Abbreviation { get; set; }
    }
}
