﻿namespace Patheyam.Common
{
    public enum SymbolPosition
    {
        Before = 1,
        After = 2
    }
}
